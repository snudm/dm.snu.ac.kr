library(xlsx)

df = read.xlsx('C:/Users/woong/Desktop/DMclass/Rcase/BathSoap.xls', 2, startRow = 3, endRow = 603)
colnames(df)
nrow(df)
df = df[,1:46]
colnames(df)

# <Problem 1>
df_m= df[,12:46]
brand = df_m[,12:20]
loyalty=apply(brand,1,max)
df_m=df_m[,-(12:20)]
df_m=cbind(df_m,loyalty)

# <Problem 2>
library(cluster)
df_m = scale(df_m)

pdf('C:/Users/woong/Desktop/DMclass/Rcase/ddf111d.pdf')
par(mfrow= c(1,3))
kc=list()
for ( i in c(3,4,5)){
        kc[[i]] = kmeans(df_m, iter.max=10,nstart=25,centers = i)
        kc[[i]]
        kc[[i]]$centers
        kc[[i]]$size
        kc[[i]]$cluster

        dissE=daisy(df_m)
        sk=silhouette(kc[[i]]$cl, dissE)
        plot(sk)
}
dev.off()

kc[[3]]$cluster
exp=cbind(df,loyalty,kc[[3]]$cluster)
write.table(exp,file="exp.csv",row.names=F)
